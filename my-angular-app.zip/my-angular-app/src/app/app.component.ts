import { Component } from '@angular/core';

@Component({
standalone:false,
  selector: 'app-root',
  templateUrl: './app.component.html',
 //styleUrls: ['./app.scss']
})
export class AppComponent {
  title = 'E-ShoppingZone Frontend';
}
